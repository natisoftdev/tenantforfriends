package com.tenantforfriend;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * This Activity is exactly the same as CaptureActivity, but has a different orientation
 * setting in AndroidManifest.xml.
 */
public class AnyOrientationCaptureActivity extends CaptureActivity {}